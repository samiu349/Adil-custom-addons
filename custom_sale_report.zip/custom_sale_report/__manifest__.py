{
    'name': 'Custom Sales Report',
    'version': '1.0.1',
    'summary': 'Professional Sales Order Report',
    'description': 'Custom PDF report for Sales Orders',
    'author': 'M Samiullah Bhatti',
    'depends': ['sale', 'stock', 'web'],
    'assets': {
        'web.report_assets_common': [
            'custom_sale_report/static/src/img/*.png',
            'security/ir.model.access.csv'
        ],
    },

    'data': [
        'reports/sale_report.xml',
        'reports/inv_report.xml',
        'reports/custom_delivery.xml',
        'reports/custom_quote.xml'
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
