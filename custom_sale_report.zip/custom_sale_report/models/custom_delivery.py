from odoo import models


class ReportDeliveryNote(models.AbstractModel):
    _name = 'report.custom_sale_report.delivery_note_template'
    _description = 'Delivery Note Report'

    def _get_report_values(self, docids, data=None):
        docs = self.env['stock.picking'].browse(docids)

        for picking in docs:
            invoice = self.env['account.move'].search([
                ('invoice_origin', '=', picking.origin),
                ('move_type', '=', 'out_invoice'),
                ('state', '=', 'posted')
            ], limit=1)

            # Set temporary attributes
            setattr(picking, 'invoice_date', invoice.invoice_date if invoice else '')
            setattr(picking, 'invoice_number', invoice.name if invoice else '')

        return {
            'doc_ids': docids,
            'doc_model': 'stock.picking',
            'docs': docs,
        }
