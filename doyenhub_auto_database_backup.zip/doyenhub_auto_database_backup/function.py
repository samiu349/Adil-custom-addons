# -*- coding: utf-8 -*-

from odoo import api, fields, models,_
from datetime import datetime



class functions_to_annual_leave (models.Model):

    
    def init(self):
    	self.env.cr.execute("""


   CREATE OR REPLACE FUNCTION public.ann_leave_allocation_odoo15(
	)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
   curr_month char (34);
   emp_id     integer ;
   hol_id integer;
   dep_id integer;
   inc float ;
   priod  integer;
   prob integer;
   joiningdate date;
   createdate date ;
   emp_rec RECORD;
   a  date;
   d  date;
   b date;
   x  float;
   dys float;
BEGIN
x=0;
for  emp_rec in

        select a.id ,department_id, a.identification_id ,to_char(a.joining_date,'mm') as current_month,round((current_date - a.joining_date) *  0.0328549,0) as months,a.joining_date as joining_date
           from hr_employee a 
    loop
        
        a=emp_rec.joining_date; --- joining date for employee as first contract
    
        b= now()::date;     -- today date
        x= (b-a);          -- today minus joining to get total number of days 
        if x > 365 then
           dys=30;
        else
           dys=24;
        end if;
           
        x =x/365*dys;      -- allocate 2.5 days per month as anual leave 
   
	   UPDATE hr_leave_allocation  SET number_of_days =x,
             write_date = now(), write_uid = 1
            WHERE holiday_status_id = 1 AND employee_id=emp_rec.id and state = 'validate';

    END LOOP;
   
  RETURN 0;
END ;
  
$BODY$;

ALTER FUNCTION public.ann_leave_allocation_odoo15()
    OWNER TO odoo;

""")
    